This is a landing page I have created using javascript
To navigate the landing page I made it easier to view by adding the scrollTo function